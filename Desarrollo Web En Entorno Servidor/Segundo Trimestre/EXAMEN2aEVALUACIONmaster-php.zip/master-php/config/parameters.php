<?php
define("base_url", "http://localhost/master-php/");
define("controller_default", "productoController");
define("action_default", "index");

