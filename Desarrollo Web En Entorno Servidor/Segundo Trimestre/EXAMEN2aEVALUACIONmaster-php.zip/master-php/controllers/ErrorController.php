<?php

class errorController{
	
	public function index(){
		echo "<h1>La página que buscas no existe</h1>";
	}
	
}